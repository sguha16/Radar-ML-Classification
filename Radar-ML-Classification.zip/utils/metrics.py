# Accuracy and confusion matrix functions
