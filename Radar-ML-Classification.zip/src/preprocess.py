# Preprocessing functions for spectrogram generation
