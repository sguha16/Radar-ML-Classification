# Training script for CNN model
