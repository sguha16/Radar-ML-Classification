# CNN model definition using PyTorch
